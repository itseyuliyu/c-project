TITLE: Smart Traffic Management System Simulation

Overview

This is a C++ project designed to simulate several aspects of the traffic management system of cities. It features maintaining vehicle records, traffic violation monitoring, and facilitating traffic control by the use of simulation. It will also be able to provide helpline information to users and details of nearby hospitals. (N.B: The system is a simulation since it has yet to be integrated with real time traffic data)

Features

1. Vehicle Records Management

Insert new vehicle information.

Searching for Vehicle Details can be done based on:

Registration Number

Owner's Name

2. Management of Traffic Violations

Record traffic violations.

Search violations based on:

Vehicle registration number.

Owner's name.

3. Traffic Control Booths

Simulate the flow of traffic in:

Addis Ababa.

Adama.

Bishoftu.

4. Helpline and Nearby Hospitals

Access the helpline numbers.

Find nearby hospitals in different cities.

Project Structure


Main Classes and Functions

SmartTrafficManagementSystem: This is the central class that does all the manipulation of the system.

Important Functions:

welcome(): For main menu display and navigating to various functionalities.

recOfVeh(): Records of the vehicle.

recOfTrafficViolations(): Recording of traffic violation.

vehSearch(): Searching vehicle records.

trafContBooth(): Traffic control booths' simulation.

helpInfo(): View helplines and hospitals.

Delays

Simulated Delays: Entering the data was simulated using the delay(), delay1(), and delay2() functions to enhance the user experience.

File Storage

Vehicles and traffic violation records in external text files:

RecordOfVehicles.txt.

RecordOfTrafficViolations.txt.